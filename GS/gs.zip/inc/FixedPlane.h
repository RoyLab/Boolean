#pragma once
#include <cstdio>
#include <hash_map>
#include "typedefs.h"
#include "Plane.h"
#include "fixed_class.h"
#include "arithmetic.h"
#include <iostream>

namespace GS{

class FixedPlane
{
public:
	FixedPlane(void) {}
    FixedPlane(const stdfixed3& normal, stdfixed d)
        :mNormal(normal)
        ,mD(d) {}
    FixedPlane (const double3& normal, const double3& pos)
        : mNormal(normal)
		{ 
			const stdfixed3 a(normal), b(pos);
			mD = -dot(a, b);
		}
	~FixedPlane(void) {}
	
    void Negate() { mNormal = -mNormal; mD = -mD;}
    bool operator == (const FixedPlane& plane) const;
    bool IsCoincidence(const FixedPlane& ) const;
    bool IsParallel(const FixedPlane&) const; 
    bool IsSimilarlyOrientation(const FixedPlane&) const;
    RelationToPlane  ClassifyPointToPlane(const stdfixed3&) const ; 
    RelationToPlane  ClassifyPointToPlane(const FixedPlane & p, const FixedPlane & q, const FixedPlane & r) const;
    const stdfixed3& Normal() const { return mNormal;}
    const stdfixed&    Distance() const {return mD;}
private :

    stdfixed3 mNormal;
    stdfixed      mD;
};

class FixedPlaneCompare : public std::binary_function<FixedPlane, FixedPlane, bool> {
public: 
	bool operator() (const FixedPlane& p1, const FixedPlane& p2)
	{
        if (vec3_lessthan(p1.Normal(), p2.Normal())) return true;
        return false ;
    }
};

static double3 ComputePoint(const FixedPlane& p, const FixedPlane& q, const FixedPlane& r)
{
    stdfixed3x3 mat; 
    mat[0] = p.Normal();
    mat[1] = q.Normal();
    mat[2] = r.Normal();
    stdfixed3 qr = cross(q.Normal(), r.Normal());
    stdfixed3 rp = cross(r.Normal(), p.Normal());
    stdfixed3 pq = cross(p.Normal(), q.Normal());
    auto res = -(p.Distance()* qr + q.Distance()* rp + r.Distance() * pq)/determinant(mat);
	return double3(res.x, res.y, res.z);
}

static bool IsPointVaild(const FixedPlane& p, const FixedPlane& q, const FixedPlane& r)
{
	stdfixed3x3 mat; 
    mat[0] = p.Normal();
    mat[1] = q.Normal();
    mat[2] = r.Normal();
	return determinant(mat).sign() != 0;
}

static std::ostream& operator<<(std::ostream& out, const FixedPlane& p)
{
	out << p.Normal()[0] << "\t" 
		<< p.Normal()[1] << "\t"
		<< p.Normal()[2] << "\t";
	out << p.Distance();
	out << std::endl;
	return out;
}

}