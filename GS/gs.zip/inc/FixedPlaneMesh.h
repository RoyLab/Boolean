#pragma once
#include <vector>
#include "typedefs.h"
#include "Box3.h"
#include "FixedPlane.h"
#include "Surface.h"
#include "FixedPolygon.h"

namespace GS{

class FixedBSPTree;
class BaseMesh;

class FixedPlaneMesh {
   
public:
    FixedPlaneMesh(const Box3& bbox)
        :mAABB(bbox){}
    FixedPlaneMesh(const BaseMesh& );
    FixedPlaneMesh(FixedBSPTree* pTree);
    void AddPolygon(const FixedPlane& plane, const float4& color, const Box3& bbox);
    void AddPolygon_Roy(const FixedPlane& plane, const float4& color, const Box3& bbox);
    void ClipPolygonByPlane(int polygonId, const FixedPlane& plane);
    int PrimitiveCount() const { return mPolygons.size();}
    std::vector<FixedPlanePolygon>& Ploygons()  {return mPolygons; }
    const Box3& AABB() const {return mAABB;}
    BaseMesh* ToBaseMesh() ;
    FixedBSPTree*  ToBSPTree(); 
protected : 
    void  CreatePolygon(const FixedPlane& splane,    const FixedPlane& xMinPlane, 
                        const FixedPlane& xMaxPlane, const FixedPlane& yMinPlane,
                        const FixedPlane& yMaxPlane, const float4& color);
     void TrianglatePolygon(const FixedPlanePolygon& poly, std::vector<Point3D>& pts, ListOfvertices& result);
private : 
    std::vector<FixedPlanePolygon>   mPolygons;
    std::vector<Box3>           mPolyAABBList;
//    std::vector<FixedPlane > mBoundPlanes;
    Box3                mAABB;
  
};



}
