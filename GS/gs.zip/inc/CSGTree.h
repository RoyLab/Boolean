#ifndef _CSG_TREE_H_
#define _CSG_TREE_H_
#include <vector>
#include <map>
#include <hash_map>
#include <assert.h>
#include "CSGExprNode.h"
#include "CSGMesh.h"
#include "tbb/blocked_range.h"
#include "tbb/parallel_for.h"

namespace GS{

 
typedef std::map<CSGRecMesh*, bool> RecMeshDict;

const int TMR_UNKNOWN  =  0;
const int TMR_INSIDE   =  1;
const int TMR_OUTSIDE  =  2;
const int TMR_SAME     =  4;
const int TMR_OPPOSITE =  8;

const int UnionRelationTable[4][4] = {
  // {TMR_INSIDE, TMR_OUTSIDE,  TMR_SAME,   TMR_OPPOSITE}  right
	 {TMR_INSIDE, TMR_INSIDE,   TMR_INSIDE, TMR_INSIDE  },// left = TMR_INSIDE
	 {TMR_INSIDE, TMR_OUTSIDE,  TMR_SAME,   TMR_OPPOSITE},// left = TMR_OUTSIDE
	 {TMR_INSIDE, TMR_SAME,     TMR_SAME,   TMR_INSIDE  },// left = TMR_SAME
	 {TMR_INSIDE, TMR_OPPOSITE, TMR_INSIDE, TMR_OPPOSITE}// left = TMR_OPPOSITE
};


const int IntersectRelationTable[4][4] = {
  // {TMR_INSIDE,   TMR_OUTSIDE,  TMR_SAME,    TMR_OPPOSITE}  right
	 {TMR_INSIDE,   TMR_OUTSIDE,  TMR_SAME,    TMR_OPPOSITE },// left = TMR_INSIDE
	 {TMR_OUTSIDE,  TMR_OUTSIDE,  TMR_OUTSIDE, TMR_OUTSIDE  },// left = TMR_OUTSIDE
	 {TMR_SAME,     TMR_OUTSIDE,  TMR_SAME,    TMR_OUTSIDE  },// left = TMR_SAME
	 {TMR_OPPOSITE, TMR_OUTSIDE,  TMR_OUTSIDE, TMR_OPPOSITE}// left = TMR_OPPOSITE
};

const int DiffRelationTable[4][4] = {
  // {TMR_INSIDE,   TMR_OUTSIDE,  TMR_SAME,    TMR_OPPOSITE}  right
	 {TMR_OUTSIDE,   TMR_INSIDE,  TMR_OPPOSITE,  TMR_SAME },// left = TMR_INSIDE
	 {TMR_OUTSIDE,  TMR_OUTSIDE,  TMR_OUTSIDE,   TMR_OUTSIDE  },// left = TMR_OUTSIDE
	 {TMR_OUTSIDE,     TMR_SAME,  TMR_OUTSIDE,   TMR_SAME  },// left = TMR_SAME
	 {TMR_OUTSIDE, TMR_OPPOSITE,  TMR_OPPOSITE,  TMR_OUTSIDE}// left = TMR_OPPOSITE
};


struct CSGInfo{
	int       TriId;
	bool      bReverse;
	CSGMesh*  pMesh;

	CSGInfo(CSGMesh* mesh, int triId, bool reverse) 
		:pMesh(mesh)
		,TriId(triId)
		,bReverse(reverse)
	{
	}
};
class CSGOpNode;
class CSGTreeNode {

public:
	virtual       ~CSGTreeNode(); 
	virtual void   Solve() = 0; 
	virtual void   GetAllMesh(RecMeshDict& CSGRecMeshDict)= 0;
	virtual bool   RelationTest(const CSGInfo& info , int Relations);
            int    RelationWith(const CSGInfo& info);
         CSGMesh*  CreateResultMesh();
protected:
	virtual int DoRelationWith(const CSGInfo& info) = 0;

protected:
	std::vector<CSGInfo> mInfoList;
	friend CSGOpNode;
};
/*TCSGTreeNode = class
    protected
      FInfoList: TList<TCSGInfo>;
      function DoRelationWith(const Info: TCSGInfo): Integer; virtual; abstract;
    public

      constructor Create;
      destructor Destroy; override;

      function RelationTest(const Info: TCSGInfo; Relations: Integer): Boolean; virtual;
      function RelationWith(const Info: TCSGInfo): Integer;
      procedure GetAllMesh(MeshDict: TDictionary<TCSGRecMesh, Boolean>); virtual; abstract;

      procedure Solve; virtual; abstract;
      function CreateResultMesh: TCSGMesh;
    end;
*/

class CSGLeafNode : public CSGTreeNode {

public:
	CSGLeafNode(CSGExprNode*  node,  std::hash_map<int, CSGRecMesh*>& recMeshDict);
	virtual ~CSGLeafNode();
	virtual void Solve();
	virtual void GetAllMesh(RecMeshDict& CSGRecMeshDict);
protected:
	virtual int DoRelationWith(const CSGInfo& info);
protected:
	CSGRecMesh* mpRecMesh;
};


/*
    TCSGLeafNode = class(TCSGTreeNode)
    protected
      FpRecMesh: TCSGRecMesh;
      function DoRelationWith(const Info: TCSGInfo): Integer; override;
    public
      constructor Create(ExprNode: TCSGExprNode; CSGRecMesh: TObjectDictionary<Integer, TCSGRecMesh>);

      procedure Solve; override;
      procedure GetAllMesh(MeshDict: TDictionary<TCSGRecMesh, Boolean>); override;
    end;*/

class CSGOpNode: public CSGTreeNode{
private:
  
     class LeftRelationTest{
            CSGOpNode*  mpOpNode;
        public:
            LeftRelationTest( CSGOpNode* pNode)
                : mpOpNode(pNode) {}
            void operator() (const tbb::blocked_range<int>& r) const ;
         
    };
     class RightRelationTest{
            CSGOpNode*  mpOpNode;
        public:
            RightRelationTest( CSGOpNode* pNode)
                : mpOpNode(pNode) {}
            void operator() (const tbb::blocked_range<int>& r) const ;
     };
public:
	CSGOpNode(const int (&relation)[4][4],CSGTreeNode* leftNode, CSGTreeNode* rightNode);
	virtual ~CSGOpNode(); 
	virtual void Solve();
	virtual void GetAllMesh(RecMeshDict& CSGRecMeshDict)
	{
		mpLeftNode->GetAllMesh(CSGRecMeshDict);
		mpRightNode->GetAllMesh(CSGRecMeshDict);
	}
protected:
	virtual int  LeftRelations() = 0;
	virtual int  RightRelations() = 0;
	virtual bool ReverseRight() {return false;}
    virtual int DoRelationWith(const CSGInfo& info);
private:
	int GetTableIndex(const int relation)
	{
		switch(relation)
		{
			case TMR_INSIDE  : return 0;
			case TMR_OUTSIDE : return 1;
			case TMR_SAME    : return 2;
			case TMR_OPPOSITE: return 3;
			default:  assert(0);
		}
	}
	



protected:
	CSGTreeNode* mpLeftNode;
	CSGTreeNode* mpRightNode;
private:
	const int (&mRelation)[4][4];
};

/*
    TCSGOperationNode = class(TCSGTreeNode)
    protected
      FLeft, FRight: TCSGTreeNode;

      function LeftRelations: Integer; virtual; abstract;
      function RightRelations: Integer; virtual; abstract;
      function ReverseRight: Boolean; virtual;
    public
      destructor Destroy; override;

      procedure Solve; override;
      procedure GetAllMesh(MeshDict: TDictionary<TCSGRecMesh, Boolean>); override;
    end;
*/

class CSGUnionNode: public CSGOpNode{
public :
	CSGUnionNode(CSGTreeNode* leftNode, CSGTreeNode* rightNode);
	virtual ~CSGUnionNode() {}
protected : 
	virtual int  LeftRelations() ;
	virtual int  RightRelations() ;
};

/*
    TCSGUnionNode = class(TCSGOperationNode)
    protected
      function LeftRelations: Integer; override;
      function RightRelations: Integer; override;
      function DoRelationWith(const Info: TCSGInfo): Integer; override;
    end;
*/
class CSGIntersectNode: public CSGOpNode{
public :
	CSGIntersectNode(CSGTreeNode* leftNode, CSGTreeNode* rightNode);
	virtual ~CSGIntersectNode() {}
protected : 
	virtual int  LeftRelations() ;
	virtual int  RightRelations() ;
};
  //TCSGIntersectNode = class(TCSGOperationNode)
  //  protected
  //    function LeftRelations: Integer; override;
  //    function RightRelations: Integer; override;
  //    function DoRelationWith(const Info: TCSGInfo): Integer; override;
  //  end;

class CSGDiffNode: public CSGOpNode{
public :
	CSGDiffNode(CSGTreeNode* leftNode, CSGTreeNode* rightNode);
	virtual ~CSGDiffNode() {}
protected : 
	virtual bool ReverseRight() {return true;}
	virtual int  LeftRelations() ;
	virtual int  RightRelations() ;
};

  //TCSGDiffNode = class(TCSGOperationNode)
  //  protected
  //    function LeftRelations: Integer; override;
  //    function RightRelations: Integer; override;
  //    function ReverseRight: Boolean; override;
  //    function DoRelationWith(const Info: TCSGInfo): Integer; override;
  //  end;

class CSGTree{

public:
	~CSGTree();
	void AddExpr(CSGExprNode* node );
    void Evaluate();
	void Clear();
    CSGMesh* GetResultCopy(CSGExprNode* node );
protected:
	void BuildTrees();
    CSGTreeNode* DoBuild(CSGExprNode* node);
protected:
	std::map<CSGExprNode*, CSGTreeNode*> mRoots;
    std::hash_map<int, CSGRecMesh*> mCSGRecMesh;
 

};

}
#endif 