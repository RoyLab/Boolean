#ifndef _OCT_TREE_H_
#define _OCT_TREE_H_
#include "typedefs.h"
#include "Box3.h"
#include "BaseMesh.h"
#include <vector>

namespace GS{

struct PolygonObj{
    Polygon poly;
    Surface<double> * pSurface;
    bool  bSurfaceModified; 

    PolygonObj()
        :pSurface(NULL)
        ,bSurfaceModified(false)
    {
    }
};

struct OctTreeNode {
    vec3<double> center;
    float3       halfWidth;
    OctTreeNode* child[8];
    Box3         bbox; 
    bool         bCritical;
    std::vector<PolygonObj*> polygons;

    OctTreeNode();
    bool IsLeaf();
   
};

class OctTree{
public:
    OctTree();
    ~OctTree();
    void BuildOctTree(std::vector<BaseMesh*>& meshes);
    void GenMeshesFromCriticalCells(std::vector<PlaneMesh*>& meshes );
    void GenMeshesFromNonCriticalCells(std::vector<BaseMesh*>& meshes );
private:
    void DeleteChilds(OctTreeNode* pNode);
    void GetLeafNodes(OctTreeNode* pNode, std::vector<OctTreeNode*>& leaves, bool bCritical);
    OctTreeNode* BuildTree(std::vector<BaseMesh*>& meshes, std::vector<PolygonObj*>& polygons, Box3& bbox, bool bCritical);
    void SplitSpaceByXYZ(const Box3& bbox, Box3 childBoxs[]);
    void DetermineCriticalCell(std::vector<BaseMesh*>& meshes, const Box3 cells[], bool bCriticals[]);
    void SplitPolygonsWithPlane(std::vector<PolygonObj*>& polygons, const Plane<double>& plane, std::vector<PolygonObj*>& left, std::vector<PolygonObj*>& right);
private : 
    OctTreeNode* mpRoot;
    std::map<int, int> mMeshOrder;
};

}



#endif 
