#pragma once
#include <vector>
#include <iostream>
#include "FixedPlane.h"
#include "Polygon.h"
#include "Box3.h"

namespace GS{

struct FixedPlanePolygon{
        FixedPlane splane;
        std::vector<FixedPlane> bplanes;
        float4          color; 
        
        void Clear() { bplanes.clear();}
       RelationToPlane ClassifyPloygonToPlane(const FixedPlane& plane) const;
       RelationToPlane ClassifyEdgeToPlane(const FixedPlane& plane, int idx) const;
       RelationToPlane ClipByPlane(const FixedPlane& bp, FixedPlanePolygon& front) const; // only output the polygon in the front of  clipping plane
       RelationToPlane ClipByPlane(const FixedPlane& bp, FixedPlanePolygon& front, FixedPlanePolygon& back) const; 
	   void Negate();
	 friend std::ostream& operator<<(std::ostream& out, const FixedPlanePolygon& poly);
private :
       OutputSymbol    LookupEncodingTable(RelationToPlane prevPtPos, RelationToPlane currentPtPos, RelationToPlane nextPtPos) const;
       RelationToPlane ReverseRelation(RelationToPlane relation) const;
};

typedef FixedPlanePolygon FFPlanePolygon;
}