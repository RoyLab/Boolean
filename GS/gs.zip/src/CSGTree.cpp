#include "tbb\tick_count.h"
#include "tbb/spin_mutex.h"
#include "CSGTree.h"

namespace GS{


CSGTreeNode::~CSGTreeNode()
{
	mInfoList.clear();
}

//CSGTreeNode Implementation 
 bool CSGTreeNode::RelationTest(const CSGInfo& info , int Relations)
 {
	 return (RelationWith(info) & Relations) >0 ;
 }

 int  CSGTreeNode::RelationWith(const CSGInfo& info)
 {
	 int result = DoRelationWith(info);
	 if (!info.bReverse)
		 return result;
	 if (result & TMR_SAME)
		 return ((result ^ TMR_SAME) | TMR_OPPOSITE);
	 else if (result & TMR_OPPOSITE)
		 return ((result ^ TMR_OPPOSITE) | TMR_SAME);
	 return result;

 }

 CSGMesh* CSGTreeNode::CreateResultMesh()
 {
	 CSGMesh* mesh = new CSGMesh(true);
	 for (int i = 0 ; i< mInfoList.size(); i++)
	 {
		 CSGInfo& info = mInfoList[i];
		 const int* VertexId = info.pMesh->TriangleInfo(info.TriId).VertexId;
		 VertexInfo  v1 = info.pMesh->Vertex(VertexId[0]);
		 VertexInfo  v2 = info.pMesh->Vertex(VertexId[1]);
		 VertexInfo  v3 = info.pMesh->Vertex(VertexId[2]);

		 if (info.bReverse)
		 {
			 v3.normal = -  v3.normal;
			 v2.normal = - v2.normal;
			 v1.normal = -v1.normal;
			 mesh->Add(v3, v2, v1);

		 }
		 else 
			 mesh->Add(v1, v2, v3);

	 }
	 return mesh;
 }
 //CSGLeafNode Implementation 

 CSGLeafNode::CSGLeafNode(CSGExprNode*  node,  std::hash_map<int, CSGRecMesh*>& recMeshDict)
	 :mpRecMesh(NULL)
 {
	 BaseMesh* pMesh = node->GetMesh();
	 if (recMeshDict.find(pMesh->GetID()) == recMeshDict.end())
	 {
		mpRecMesh = new CSGRecMesh(node->GetMesh());
		recMeshDict[pMesh->GetID()]= mpRecMesh;

	 }
 }


 CSGLeafNode::~CSGLeafNode()
 {
	 if (mpRecMesh !=NULL)
		 delete mpRecMesh; 
	 mpRecMesh= NULL;
 }

 void CSGLeafNode::Solve()
 {
     mInfoList.clear();
     mInfoList.reserve(mpRecMesh->mpTriMesh->PrimitiveCount());
	 for( int i = 0; i< mpRecMesh->mpTriMesh->PrimitiveCount(); i++)
	 {
		 CSGInfo info(mpRecMesh->mpTriMesh, i, false);
		 mInfoList.push_back(info);
	 }
 }

 void CSGLeafNode::GetAllMesh(RecMeshDict& CSGRecMeshDict)
 {
	 if(CSGRecMeshDict.find(mpRecMesh) ==CSGRecMeshDict.end() )
		CSGRecMeshDict[mpRecMesh] = true;
 }

int CSGLeafNode::DoRelationWith(const CSGInfo& info)
{
	Point3D point = info.pMesh->CenterOfGravity(info.TriId);
	Vec3D   normal = info.pMesh->TriangleInfo(info.TriId).Normal;
	PointMeshRelation  relation = mpRecMesh->mpBaseMesh->RelationWith(point, normal);
	switch (relation)
	{
		case pmrInside:    return TMR_INSIDE;
		case pmrSame :     return TMR_SAME;
		case pmrOpposite : return TMR_OPPOSITE;
		case pmrOutside:   return TMR_OUTSIDE;
		default :          assert(0);
	}
	return TMR_UNKNOWN;
}


//CSGOpNode Implementation
CSGOpNode::CSGOpNode(const int (&relation)[4][4], CSGTreeNode* leftNode, CSGTreeNode* rightNode)
	:mRelation(relation)
	,mpLeftNode(leftNode)
	,mpRightNode(rightNode)
{
}

CSGOpNode::~CSGOpNode()
{
	if (mpLeftNode)
		delete mpLeftNode;
	if (mpRightNode)
		delete mpRightNode;
}

tbb::spin_mutex RealtionTestMutex;

void CSGOpNode::LeftRelationTest::operator()(const tbb::blocked_range<int>& r) const 
{
    int leftRs = mpOpNode->LeftRelations();
     int RRs = mpOpNode->RightRelations();
	for (int i = r.begin(); i != r.end(); i++)
	{
       
        CSGInfo& info = mpOpNode->mpLeftNode->mInfoList[i];
        //to do May have problem for INFO copy  
        if (mpOpNode->mpRightNode->RelationTest(info, leftRs))
        {
            tbb::spin_mutex::scoped_lock  lock(RealtionTestMutex);
            {
                mpOpNode->mInfoList.push_back(info);
            }

        }
    }
}

void CSGOpNode::RightRelationTest::operator()(const tbb::blocked_range<int>& r) const 
{
    int RRs = mpOpNode->RightRelations();
    for (int i = r.begin(); i != r.end(); i++)
    {
        CSGInfo& info = mpOpNode->mpRightNode->mInfoList[i];
        //to do May have problem for INFO copy  
        if ( mpOpNode->mpLeftNode->RelationTest(info, RRs))
        {
            CSGInfo rInfo = info;
            if (mpOpNode->ReverseRight())
                rInfo.bReverse = !rInfo.bReverse;
            tbb::spin_mutex::scoped_lock  lock(RealtionTestMutex);
            {
                mpOpNode->mInfoList.push_back(rInfo);
            }
        }
    }
}

void CSGOpNode::Solve()
{
   
	mpLeftNode->Solve();
	mpRightNode->Solve();
    int number = mpLeftNode->mInfoList.size() + mpRightNode->mInfoList.size();
    mInfoList.reserve(number);

    tbb::parallel_for(tbb::blocked_range<int>(0,mpLeftNode->mInfoList.size(),16), LeftRelationTest(this));
    tbb::parallel_for(tbb::blocked_range<int>(0,mpRightNode->mInfoList.size(),16), RightRelationTest(this));
   /*         tbb::tick_count t1 = tbb::tick_count::now();
    WCHAR buffer [100];
    ::swprintf_s(buffer, 100, L"Time %f Sec", (t1-t0).seconds());
    ::MessageBox(NULL, buffer, L"Warning", MB_OK); */
	//int LRs = LeftRelations();
	//int RRs = RightRelations();
	//for (int i = 0; i< mpLeftNode->mInfoList.size(); i++)
	//{
	//	CSGInfo& info = mpLeftNode->mInfoList[i];
	//	//to do May have problem for INFO copy  
	//	if (mpRightNode->RelationTest(info, LRs))
	//		mInfoList.push_back(info);
	//}
	//for (int i = 0; i< mpRightNode->mInfoList.size(); i++)
	//{
	//	CSGInfo& info = mpRightNode->mInfoList[i];
	//	//to do May have problem for INFO copy  
	//	if (mpLeftNode->RelationTest(info, RRs))
	//	{
	//		if (ReverseRight())
	//		{
	//			CSGInfo rInfo = info;
	//			rInfo.bReverse = !info.bReverse;
	//			mInfoList.push_back(rInfo);
	//		}
	//		else
	//			mInfoList.push_back(info);
	//	}
	//}
     
	
}
	
int CSGOpNode::DoRelationWith(const CSGInfo& info)
{
	int leftIndex  = GetTableIndex(mpLeftNode->RelationWith(info));
	int rightIndex = GetTableIndex(mpRightNode->RelationWith(info));
	return mRelation[leftIndex][rightIndex];
}

// CSGUnionNode Implementation 
CSGUnionNode::CSGUnionNode(CSGTreeNode* leftNode, CSGTreeNode* rightNode)
	:CSGOpNode(UnionRelationTable, leftNode, rightNode)
{
}

int CSGUnionNode::LeftRelations()
{
	return (TMR_OUTSIDE | TMR_SAME);
}

int CSGUnionNode::RightRelations()
{
	return TMR_OUTSIDE;
}

// CSGIntersectNode Implementation
CSGIntersectNode::CSGIntersectNode(CSGTreeNode* leftNode, CSGTreeNode* rightNode)
	:CSGOpNode(IntersectRelationTable, leftNode, rightNode)
{
}

int CSGIntersectNode::LeftRelations()
{
	return ( TMR_INSIDE | TMR_SAME);
}

int CSGIntersectNode::RightRelations()
{
	return TMR_INSIDE;
}

//// CSGDiffNode Implementation
CSGDiffNode::CSGDiffNode(CSGTreeNode* leftNode, CSGTreeNode* rightNode)
	:CSGOpNode(DiffRelationTable, leftNode, rightNode)
{
}

int CSGDiffNode::LeftRelations()
{
	return ( TMR_OUTSIDE | TMR_OPPOSITE);
}

int CSGDiffNode::RightRelations()
{
	return TMR_INSIDE;
}
//////////////////////////////////////////////////////

CSGTree::~CSGTree()
{
	Clear();
}


void CSGTree::AddExpr(CSGExprNode* node )
{
	if(mRoots.find(node) == mRoots.end())
		mRoots[node] = NULL;
}

/*
procedure TCSGTree.Evaluate;
var
  i, j: integer;
  CSGArray: TArray<TCSGRecMesh>;
  AllMesh: TDictionary<TCSGRecMesh, Boolean>;
  Pair: TPair<TCSGExprNode, TCSGTreeNode>;
  testPair: TCSGRecMeshPair;
  InterCarveDict: TDictionary<TCSGRecMeshPair, Boolean>;
begin
  AllMesh := TDictionary<TCSGRecMesh, Boolean>.Create(1024);
  InterCarveDict := TDictionary<TCSGRecMeshPair, Boolean>.Create(1024, TCSGRecMeshPairCmper.Create);
  try
    BuildTrees;

    for Pair in FRoots do
      if Assigned(Pair.Value) then
      begin
        AllMesh.Clear;
        Pair.Value.GetAllMesh(AllMesh);
        CSGArray := AllMesh.Keys.ToArray;
        for i := Low(CSGArray) to High(CSGArray) - 1 do
          for j := i + 1 to High(CSGArray) do
          begin
            testPair.Key := CSGArray[i];
            testPair.Value := CSGArray[j];
            if not InterCarveDict.ContainsKey(testPair) then
              InterCarveDict.Add(testPair, True);
          end;
      end;

      for testPair in InterCarveDict.Keys do
        testPair.Key.InterCarve(testPair.Value);

      CSGArray := FCSGRecMesh.Values.ToArray;
      for i := Low(CSGArray) to High(CSGArray) do
      begin
        CSGArray[i].Triangulate;
        FreeAndNil(CSGArray[i].CarveMesh);
      end;

      for Pair in FRoots do
        if Assigned(Pair.Value) then
          Pair.Value.Solve;
  finally
    AllMesh.Free;
    InterCarveDict.Free;
  end;
end;
*/
void CSGTree::Evaluate()
{
	CSGRecMeshPair testPair;
	std::map<CSGRecMeshPair, bool> InterCarveDict;
 
	RecMeshDict AllMesh;
      
	BuildTrees();
      
   
	std::map<CSGExprNode*, CSGTreeNode*>::iterator iter = mRoots.begin();
	for(;iter!=mRoots.end();++iter)
	{
		if(iter->second)
		{
			iter->second->GetAllMesh(AllMesh);
			std::vector<CSGRecMesh*> recMeshList(AllMesh.size());
			RecMeshDict::iterator recMeshIter= AllMesh.begin();
			for (int i = 0; recMeshIter != AllMesh.end(); i++,recMeshIter++)
			{
				recMeshList[i] = recMeshIter->first;
			}

			for(int i = 0 ; i < recMeshList.size()-1; i++)
			{
				for (int j = i+1; j < recMeshList.size(); j++)
				{
					testPair.first = recMeshList[i];
					testPair.second = recMeshList[j];
					if (InterCarveDict.find(testPair) == InterCarveDict.end())
						InterCarveDict[testPair] = true;
				}
			}
			recMeshList.clear();
		}
	}

	std::map<CSGRecMeshPair, bool>::iterator pairIter = InterCarveDict.begin();
	for (; pairIter !=InterCarveDict.end(); pairIter++ )
		pairIter->first.first->InterCarve(*pairIter->first.second);

     
	std::hash_map<int, CSGRecMesh*>::iterator it = mCSGRecMesh.begin();
	for(;it!=mCSGRecMesh.end();++it)
	{
		it->second->Triangulate();
		it->second->ClearCarveMesh();
	}
   

	iter = mRoots.begin();

	for(;iter!=mRoots.end();++iter)
	{
		iter->second->Solve();
	}

	AllMesh.clear();
	InterCarveDict.clear();

}

/*procedure TCSGTree.Clear;
begin
  FCSGRecMesh.Clear;
  FRoots.Clear;
end;*/

void CSGTree::Clear()
{
	std::map<CSGExprNode*, CSGTreeNode*>::iterator iter = mRoots.begin();
	for(;iter!=mRoots.end();++iter)
	{
		delete iter->second;
		delete iter->first;
	}
	mRoots.clear();
	/*std::hash_map<int, CSGRecMesh*>::iterator recMeshIter= mCSGRecMesh.begin();
	for(; recMeshIter != mCSGRecMesh.end(); recMeshIter++)
		delete recMeshIter->second;*/
	mCSGRecMesh.clear();
}

CSGMesh* CSGTree::GetResultCopy(CSGExprNode* node )
{
	if(mRoots.find(node)!= mRoots.end())
		return  mRoots[node]->CreateResultMesh();
	return NULL;
}

CSGTreeNode* CSGTree::DoBuild(CSGExprNode* node)
{
	if (node == NULL)
		return NULL;
	if (node->GetMesh())
		return new CSGLeafNode(node, mCSGRecMesh);
	CSGOpNode* TreeOpNode = NULL; 
	switch (node->BoolOperation())
	{
		case CSGUnion: 
			TreeOpNode = new CSGUnionNode(DoBuild(node->LeftNode()), DoBuild(node->RightNode()));
		    break; 
		case CSGIntersect:
			TreeOpNode = new CSGIntersectNode(DoBuild(node->LeftNode()), DoBuild(node->RightNode()));
			break;
		case CSGDiff:
			TreeOpNode = new CSGDiffNode(DoBuild(node->LeftNode()), DoBuild(node->RightNode()));
			break;
		default :
			assert(0);
	}
    return TreeOpNode;
}

void CSGTree::BuildTrees()
{
	std::map<CSGExprNode*, CSGTreeNode*>::iterator iter = mRoots.begin();
	for(;iter!=mRoots.end();++iter)
	{
		mRoots[iter->first] = DoBuild(iter->first);
	}

}

};