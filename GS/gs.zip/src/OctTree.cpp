#include "OctTree.h"


namespace GS{




////////////////////////////////////////////////////////////////////
OctTreeNode::OctTreeNode()
    : bCritical(false)
{
    for (int i =0; i < 8 ; i++)
        child[i] = NULL;

}

bool OctTreeNode::IsLeaf()
{
   return child[0] == NULL;
}
/////////////////////////////////////////////////////////////////////

OctTree::OctTree()
    :mpRoot(NULL)
{
}

OctTree::~OctTree()
{
    DeleteChilds(mpRoot);
}


void OctTree::DeleteChilds(OctTreeNode* pNode)
{
    if (pNode != NULL)
    {
        for (int i = 0; i < 8; i++)
        {
            DeleteChilds (pNode->child[i]);
        }
        delete pNode;
    }
    pNode = NULL;
      
}


void OctTree::BuildOctTree(std::vector<BaseMesh*>& meshs)
{
    std::vector<PolygonObj*> polygons;
    Box3 bbox;
    int nPolygons = 0; 
    for (int i = 0; i < meshs.size(); i++)
        nPolygons+=meshs[i]->Surfaces().size();
    polygons.reserve(nPolygons);

    for(int i = 0 ; i < meshs.size(); i++)
    {
        bbox.IncludeBox(meshs[i]->AABB());
        for (int j = 0 ; j < meshs[i]->Surfaces().size(); j++)
        {
            ListOfSurfaces& surfaces = meshs[i]->Surfaces();
            PolygonObj* pObj = new PolygonObj;
            pObj->pSurface = surfaces[j];
            pObj->pSurface->GetLine(pObj->poly.points);
            pObj->poly.normal = pObj->pSurface->N();
            pObj->poly.bbox = pObj->pSurface->AABB();
            pObj->poly.color = pObj->pSurface->SurfaceColor();
            polygons.push_back(pObj);
        }
    }
    mMeshOrder.clear();
    for (int i = 0; i < meshs.size(); i++)
    {
        mMeshOrder[meshs[i]->GetID()] = i;
    }

    mpRoot = BuildTree(meshs, polygons, bbox, true);
    polygons.clear();
}


OctTreeNode* OctTree::BuildTree(std::vector<BaseMesh*>& meshes, std::vector<PolygonObj*>& polygons, Box3& bbox, bool bCritical)
{
     OctTreeNode* pNode = new OctTreeNode;
     pNode ->center   = bbox.Center();
     pNode->halfWidth = (bbox.Max() - bbox.Min())* 0.5f;
     pNode->bbox      = bbox;
     pNode->bCritical = bCritical;
    if(polygons.size() <= 17 || !bCritical)
    {
        pNode->polygons  = polygons;
        return pNode;
    }

    Plane<double> XPlane(vec3<double>(-1, 0, 0), (bbox.Min().x+bbox.Max().x)*0.5f);
    Plane<double> YPlane(vec3<double>(0, -1, 0), (bbox.Min().y+bbox.Max().y)*0.5f);
    Plane<double> ZPlane(vec3<double>(0, 0, -1), (bbox.Min().z+bbox.Max().z)*0.5f);
    //split space by XYZ 
    Box3 childBoxes[8];
    SplitSpaceByXYZ(bbox, childBoxes);
    bool bCriticalCells[8];
    memset(bCriticalCells, 0 , 8);
    if (bCritical)
        DetermineCriticalCell(meshes, childBoxes, bCriticalCells);
    std::vector<PolygonObj*> XSplits[2];
    SplitPolygonsWithPlane(polygons, XPlane, XSplits[0], XSplits[1] ); 
    std::vector<PolygonObj*> XYSplits[4];
    for (int i = 0 , j = 0 ; i< 2; i++, j++)
    {
         SplitPolygonsWithPlane(XSplits[i], YPlane, XYSplits[j], XYSplits[j+2] ); 
         XSplits[i].clear();
    }
    std::vector<PolygonObj*> XYZSplits[8];
    for (int i = 0, j =0 ; i < 4; i++, j++)
    {
         SplitPolygonsWithPlane(XYSplits[i], ZPlane, XYZSplits[j], XYZSplits[j+4] ); 
         XYSplits[i].clear();
    }
    for (int i = 0; i < 8 ; i++)
    {
        pNode->child[i] = BuildTree(meshes, XYZSplits[i], childBoxes[i], bCriticalCells[i]);
        XYZSplits[i].clear();
    }
    return pNode;
}


void OctTree::GenMeshesFromCriticalCells(std::vector<PlaneMesh*>& meshes )
{
     std::vector<OctTreeNode*> leaves;
     GetLeafNodes(mpRoot, leaves, true);
     if (leaves.size() == 0)
        return ; 
     meshes.resize(mMeshOrder.size());
     for (int i = 0 ; i < meshes.size(); i++)
         meshes[i] = NULL;
     for(int i = 0 ; i < leaves.size(); i++)
     {
         for (int j = 0 ; j < leaves[i]->polygons.size(); j++)
         {
             PolygonObj* polyObj = leaves[i]->polygons[j];
             int index = mMeshOrder[polyObj->pSurface->GetParent()->GetID()];
             if (meshes[index] == NULL)
                 meshes[index] = new PlaneMesh(polyObj->poly.bbox);
             meshes[index]->AddPolygon(polyObj->poly);
         }
     }
}


void OctTree::GenMeshesFromNonCriticalCells(std::vector<BaseMesh*>& meshes )
{
    std::vector<OctTreeNode*> leaves;
    GetLeafNodes(mpRoot, leaves, false);
    if (leaves.size() == 0)
        return ; 
    meshes.resize(mMeshOrder.size());
    for (int i = 0 ; i < meshes.size(); i++)
         meshes[i] = NULL;
    for(int i = 0 ; i < leaves.size(); i++)
    {
         for (int j = 0 ; j < leaves[i]->polygons.size(); j++)
         {
              PolygonObj* polyObj = leaves[i]->polygons[j];
             int index = mMeshOrder[polyObj->pSurface->GetParent()->GetID()];
             if (meshes[index] == NULL)
                 meshes[index] = new BaseMesh();
             if (!polyObj->bSurfaceModified)
             {
                 meshes[index]->AddSurface(polyObj->pSurface);
             }else  {
             
                ListOfvertices results; 
                polyObj->poly.Trianglate(results);
                for (int k = 0 ; k < results.size(); k+=3)
                {   
                    meshes[index]->Add(results[k], results[k+1], results[k+2], polyObj->poly.normal);
                }
		        results.clear();
             }
         }
    }

}

void OctTree::GetLeafNodes(OctTreeNode* pNode, std::vector<OctTreeNode*>& leaves, bool bCritical)
{
    if (pNode == NULL)
        return; 
    if (pNode->IsLeaf())
    {
        if (bCritical == pNode->bCritical)
            leaves.push_back(pNode);
        return ;
    }
    for ( int i = 0; i < 8 ; i++)
    {
        GetLeafNodes(pNode->child[i], leaves, bCritical);
    }
}




void OctTree::SplitPolygonsWithPlane( std::vector<PolygonObj*>& polygons, const Plane<double>& plane, std::vector<PolygonObj*>& left, std::vector<PolygonObj*>& right)
{
    for (int i = 0; i < polygons.size(); i++)
    {
        RelationToPlane rp =polygons[i]->poly.ClassifyPloygonToPlane(plane);
        switch (rp)
        {
            case On:
            {    Plane<double> PolygonPlane(polygons[i]->poly.normal, polygons[i]->poly.points[0]);
                if (plane.IsSimilarlyOrientation(PolygonPlane))
                    left.push_back(polygons[i]);
                else right.push_back(polygons[i]);
                break;
            }
            case Front: 
                left.push_back(polygons[i]);
                break;
            case Behind:
                right.push_back(polygons[i]);
                break;
            case Straddling:
            {
                PolygonObj* pLeft = new PolygonObj;
                PolygonObj* pRight = new PolygonObj;
                polygons[i]->poly.ClipByPlane(plane, pLeft->poly, pRight->poly);
                pLeft->pSurface = pRight->pSurface = polygons[i]->pSurface;
                // Set Triangulate flag 
                pLeft->bSurfaceModified = pRight->bSurfaceModified = true;
                // delete original polygon 
                delete polygons[i];
                polygons[i] = NULL;
                left.push_back(pLeft);
                right.push_back(pRight);
                break;
            }
            default :
                break;

        }
    }

}

void OctTree::SplitSpaceByXYZ(const Box3& bbox,  Box3 childBoxes[])
{
    vec3<float> minOffset, maxOffset; 
    float3 step = (bbox.Max() - bbox.Min())* 0.5f;

    for (int i = 0; i < 8 ; i++)
    {
        maxOffset.x = i & 1 ?  0 : -step.x; 
        maxOffset.y = i & 2 ?  0 : -step.y;
        maxOffset.z = i & 4 ?  0 : -step.z;
        minOffset.x = i & 1 ?  step.x : 0; 
        minOffset.y = i & 2 ?  step.y : 0;
        minOffset.z = i & 4 ?  step.z : 0;
        childBoxes[i].Set(bbox.Min() + minOffset, bbox.Max()+ maxOffset);
    }
}

void OctTree::DetermineCriticalCell(std::vector<BaseMesh*>& meshes,const Box3 cells[], bool bCriticals[])
{
    
    for (int i = 0 ; i < 8 ; i++)
    {
        bCriticals[i] = false ;
        const Box3& box = cells[i];
        int nInterected = 0; 
        for (int j = 0; j < meshes.size(); j++)
        {
            if (box.Intersects(meshes[j]->AABB()))
                nInterected++; 
            if (nInterected >= 2)
            {
                bCriticals[i] = true;
                break;
            }
        }
    }
}


}