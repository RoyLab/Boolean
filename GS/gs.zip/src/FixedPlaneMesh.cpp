#include <CGAL/Exact_predicates_inexact_constructions_kernel.h>
#include <CGAL/Constrained_Delaunay_triangulation_2.h>
#include <CGAL/Triangulation_conformer_2.h>
#include "configure.h"
#include "FixedPlaneMesh.h"
#include "BaseMesh.h"
#include "topology.h"
#include "fixed_class.h"
#include "fixedBSPTree.h"


namespace GS{




/////////////////////////////////////////////////////////////////////
 FixedPlaneMesh::FixedPlaneMesh(const BaseMesh& mesh)
 {
     // generate  polygons 
 }


FixedPlaneMesh::FixedPlaneMesh(FixedBSPTree* pTree)
{
    pTree->GetPolygons(mPolygons);
}

void FixedPlaneMesh::AddPolygon_Roy(const FixedPlane& plane, const float4& color, const Box3& bbox)
{
    FixedPlanePolygon poly;
    poly.splane = plane ;
    poly.color = color;
    mPolygons.push_back(poly);
}

 void FixedPlaneMesh::AddPolygon(const FixedPlane& plane, const float4& color, const Box3& bbox)
{
    FixedPlane xMin(vec3<double>(1, 0, 0),  bbox.Min());
    FixedPlane xMax(vec3<double>(-1, 0, 0),  bbox.Max());
    FixedPlane yMin(vec3<double>(0, 1, 0),  bbox.Min());
    FixedPlane yMax(vec3<double>(0, -1, 0),  bbox.Max());
    FixedPlane zMin(vec3<double>(0, 0, 1),  bbox.Min());
    FixedPlane zMax(vec3<double>(0, 0, -1),  bbox.Max());
    if (plane.IsParallel(xMin)){
        CreatePolygon(plane, yMin, yMax, zMin, zMax, color);
    }else if (plane.IsParallel(yMin)){
        CreatePolygon(plane, xMin, xMax, zMin, zMax, color);
    }else if (plane.IsParallel(zMin)) {
        CreatePolygon(plane, xMin, xMax, yMin, yMax, color);
    }else if (IsPointVaild(plane, xMin, yMin)){
        CreatePolygon(plane, xMin, xMax, yMin, yMax, color);
        ClipPolygonByPlane(mPolygons.size()-1, zMin);
        ClipPolygonByPlane(mPolygons.size()-1, zMax);
    }else {
        CreatePolygon(plane, xMin, xMax, zMin, zMax, color);
        ClipPolygonByPlane(mPolygons.size()-1, yMin);
        ClipPolygonByPlane(mPolygons.size()-1, yMax);
       
       
    
    }
}

void FixedPlaneMesh::ClipPolygonByPlane(int polygonId, const FixedPlane& plane)
{
    FixedPlanePolygon front;
    RelationToPlane rp = mPolygons[polygonId].ClipByPlane(plane, front);
    if (rp == On)
    {
        if (!plane.IsSimilarlyOrientation(mPolygons[polygonId].splane))
            mPolygons.erase(mPolygons.begin()+ polygonId);
        return;
    }
    mPolygons[polygonId].bplanes = front.bplanes;
   
}

void FixedPlaneMesh::CreatePolygon(const FixedPlane& splane, const FixedPlane& xMinPlane, 
                      const FixedPlane& xMaxPlane, const FixedPlane& yMinPlane,
                      const FixedPlane& yMaxPlane, const float4& color )
{
    FixedPlanePolygon poly;
    poly.splane = splane ;
    poly.color = color;
    poly.bplanes.push_back(yMinPlane);
    poly.bplanes.push_back(xMaxPlane);
    poly.bplanes.push_back(yMaxPlane);
    poly.bplanes.push_back(xMinPlane);
    mPolygons.push_back(poly);
}

 BaseMesh* FixedPlaneMesh::ToBaseMesh() 
 {
     std::vector<Point3D > pts; 
     ListOfvertices results;
     BaseMesh* pMesh = new BaseMesh;
     for (int i = 0 ; i < mPolygons.size(); i++)
     {
        for (int j = 0 ; j < mPolygons[i].bplanes.size(); j++)
        {
            int prevPtIdx = j == 0? mPolygons[i].bplanes.size() -1 : j -1;
            Point3D pt = ComputePoint(mPolygons[i].splane, mPolygons[i].bplanes[prevPtIdx], mPolygons[i].bplanes[j] );
			//if (pt.x > 35 || pt.x < 24.8 || pt.y > 17.1 || pt.y < 7 || pt.z > 5.1 || pt.z < -5.1) assert(0);
            pts.push_back(pt);
        }
        try
		{
			TrianglatePolygon(mPolygons[i], pts, results);
		}
		catch (...)
		{
			results.clear();
		}

        for (int k = 0 ; k < results.size(); k+=3)
        {   
            pMesh->Add(results[k], results[k+1], results[k+2], toDouble3(mPolygons[i].splane.Normal()));
        }
        pts.clear();
		results.clear();
     }
     pMesh->GenID();
     pMesh->GenAABB(true);
     return pMesh;
 }

 void FixedPlaneMesh::TrianglatePolygon(const FixedPlanePolygon& poly, std::vector<Point3D>& pts, ListOfvertices& results)
 {
    if (pts.size() < 3)
        return ; 
    if (pts.size() ==3)
    {
       VertexInfo vi1(pts[0], toDouble3(poly.splane.Normal()), poly.color);
       VertexInfo vi2(pts[1], toDouble3(poly.splane.Normal()), poly.color);
       VertexInfo vi3(pts[2], toDouble3(poly.splane.Normal()), poly.color);
       results.push_back(vi1);
       results.push_back(vi2);
       results.push_back(vi3);
       return ;
    }
    typedef CGAL::Exact_predicates_inexact_constructions_kernel K;

    typedef CGAL::Triangulation_vertex_base_2<K>                     Vb;
    typedef CGAL::Constrained_triangulation_face_base_2<K>           Fb;
    typedef CGAL::Triangulation_data_structure_2<Vb,Fb>              TDS;
     //typedef CGAL::Exact_predicates_tag                               Itag;
    typedef CGAL::Constrained_Delaunay_triangulation_2<K, TDS, CGAL::No_intersection_tag> CDT;

    vec3<double> origin = pts[0];
    vec3<double>  N = toDouble3(poly.splane.Normal());
    vec3<double>  U = normalize(pts[1] - origin);
    vec3<double>  V = cross(N, U);
    CDT cdt;
    CDT::Vertex_handle vh1, vh2, vh3;
    vec3<double> v0 = PosToLocal(U, V, N, origin, pts[0]);
    CDT::Point p0(v0.x, v0.y);
    vh1 = vh3 = cdt.insert(p0);
    for ( int i = 1; i< pts.size() ; i++)
    {
        vec3<double> v1 = PosToLocal(U, V, N, origin, pts[i]);
        CDT::Point p1(v1.x, v1.y);
        vh2 = cdt.insert(p1);
        cdt.insert_constraint(vh1, vh2);
        vh1 = vh2;
    }
    cdt.insert_constraint(vh2, vh3);
    int count = cdt.number_of_faces() ; 
    results.reserve(count*3);
    for (CDT::Finite_faces_iterator fit = cdt.finite_faces_begin();
       fit != cdt.finite_faces_end(); ++fit)
   {
	   vec2<double> v0(fit->vertex(2)->point().x(),fit->vertex(2)->point().y() );
	   vec2<double> v1(fit->vertex(1)->point().x(),fit->vertex(1)->point().y() );
	   vec2<double> v2(fit->vertex(0)->point().x(),fit->vertex(0)->point().y() );   
	   if (IsEqual(cross(v0- v2, v1-v2), (double)0.,  (double)EPSF ))
		   continue; //
       vec3<double > p0(v0, 0.0);
       vec3<double > p1(v1, 0.0);
       vec3<double > p2(v2, 0.0);
       p0 = PosToGlobal(U, V, N, origin, p0);
       p1 = PosToGlobal(U, V, N, origin, p1);
       p2 = PosToGlobal(U, V, N, origin, p2);
       VertexInfo vi1(p0, N, poly.color);
       VertexInfo vi2(p1, N, poly.color);
       VertexInfo vi3(p2, N, poly.color);
       results.push_back(vi1);
       results.push_back(vi2);
       results.push_back(vi3);
   }
  
 }



 FixedBSPTree*  FixedPlaneMesh::ToBSPTree()
 {
     FixedBSPTree* bsp = new FixedBSPTree();
     bsp->BuildBSPTree(mPolygons);
     return bsp;
 }



} 