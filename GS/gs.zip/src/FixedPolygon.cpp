#include "FixedPolygon.h"
#include "topology.h"

namespace GS{

/////////////////////////////////////////////////////////////////////
std::ostream& operator<<(std::ostream& out, const FixedPlanePolygon& poly)
{
	out << "splane: \n";
	out << poly.splane;
	out << "bplane: \n";
	for (int i = 0; i < poly.bplanes.size(); i++)
	{
		out << poly.bplanes[i];
	}
	out << "to be implemented.\n";
	return out;
}

RelationToPlane FixedPlanePolygon::ClassifyPloygonToPlane(const FixedPlane& plane) const
{
    int numInFront = 0 ; 
    int numInBack = 0; 
    
    for (int i = 0; i < bplanes.size(); i++)
    {
         int pBpId = i > 0? i -1: bplanes.size() -1;
         RelationToPlane PtToPlane= plane.ClassifyPointToPlane(splane, bplanes[pBpId], bplanes[i]);
         if (PtToPlane == Front)
             numInFront++;
         else if (PtToPlane == Behind)
             numInBack ++;
    }
    if (numInFront != 0 && numInBack != 0)
        return Straddling;
    if (numInFront != 0)
        return Front;
    if (numInBack != 0)
        return Behind;
    return On;

}


RelationToPlane FixedPlanePolygon::ClassifyEdgeToPlane(const FixedPlane& plane, int idx) const
{
     int nSize = bplanes.size();
     int pBpId = idx > 0? idx -1: nSize -1;
     int aBpId = idx +1 >= nSize? 0: idx +1; 
     // classify  point Vx-1 , Vx , Vx+1 to Plane  bp
     RelationToPlane currentPtPos= plane.ClassifyPointToPlane(splane, bplanes[pBpId], bplanes[idx]);
     RelationToPlane nextPtPos = plane.ClassifyPointToPlane(splane,   bplanes[idx], bplanes[aBpId]);
     if (nextPtPos == On)
         return currentPtPos;
     if (currentPtPos == On)
         return nextPtPos;
     if (currentPtPos != nextPtPos)
         return Straddling;
     return currentPtPos;    
}


// Clip polygon and only output the polygon in the front of plane 
RelationToPlane FixedPlanePolygon::ClipByPlane(const FixedPlane& bp, FixedPlanePolygon& front) const
{
     if (splane.IsCoincidence(bp))
        return On;

    int nBPlanes =  bplanes.size();
    bool bPlaneInserted = false ; 
    for (int i = 0 ; i <  bplanes.size(); i++)
    {
        int ppBpId = i  > 1 ? i -2 : (i+nBPlanes -2)% nBPlanes;
        int pBpId = i > 0? i -1: nBPlanes -1;
        int aBpId = i +1 >= nBPlanes? 0: i +1; 
        // classify  point Vx-1 , Vx , Vx+1 to Plane  bp
        RelationToPlane  prevPtPos = bp.ClassifyPointToPlane( splane, bplanes[ppBpId], bplanes[pBpId]);
        RelationToPlane currentPtPos= bp.ClassifyPointToPlane(splane, bplanes[pBpId],  bplanes[i]);
        RelationToPlane nextPtPos = bp.ClassifyPointToPlane(splane, bplanes[i], bplanes[aBpId]);
        OutputSymbol signal =  LookupEncodingTable(prevPtPos, currentPtPos, nextPtPos);
        switch (signal)
        {
            case B:
                front.bplanes.push_back(bplanes[i]);
                break;
            case HB:
                if (!bPlaneInserted)
                {
                    front.bplanes.push_back(bp);
                    bPlaneInserted = true;
                }
                front.bplanes.push_back(bplanes[i]);
                break;
            default:
                break;
        }
    }
    front.splane = splane;
    front.color = color;
    return Front;

}


RelationToPlane FixedPlanePolygon::ClipByPlane(const FixedPlane& bp, FixedPlanePolygon& front, FixedPlanePolygon& back) const
{
     if (splane.IsCoincidence(bp))
        return On;

    int nBPlanes =  bplanes.size();
    bool bFrontInserted = false ; 
    bool bBackInserted = false ; 
    for (int i = 0 ; i <  bplanes.size(); i++)
    {
        int ppBpId = i  > 1 ? i -2 : (i+nBPlanes -2)% nBPlanes;
        int pBpId = i > 0? i -1: nBPlanes -1;
        int aBpId = i +1 >= nBPlanes? 0: i +1; 
        // classify  point Vx-1 , Vx , Vx+1 to Plane  bp
        RelationToPlane  prevPtPos = bp.ClassifyPointToPlane( splane, bplanes[ppBpId], bplanes[pBpId]);
        RelationToPlane currentPtPos= bp.ClassifyPointToPlane(splane, bplanes[pBpId],  bplanes[i]);
        RelationToPlane nextPtPos = bp.ClassifyPointToPlane(splane, bplanes[i], bplanes[aBpId]);

        OutputSymbol signal =  LookupEncodingTable(prevPtPos, currentPtPos, nextPtPos);
        switch (signal)
        {
            case B:
                front.bplanes.push_back(bplanes[i]);
                break;
            case HB:
                if (!bFrontInserted)
                {
                    front.bplanes.push_back(bp);
                    bFrontInserted = true;
                }
                front.bplanes.push_back(bplanes[i]);
                break;
            default:
                break;
        }
       
        // output back plane
        OutputSymbol backSignal =  LookupEncodingTable(ReverseRelation(prevPtPos), ReverseRelation(currentPtPos), ReverseRelation(nextPtPos));
        switch (backSignal)
        {
            case B:
                back.bplanes.push_back(bplanes[i]);
                break;
            case HB:
                if (!bBackInserted)
                {
                    FixedPlane hp (-bp.Normal(), -bp.Distance());
                    back.bplanes.push_back(hp);
                    bBackInserted = true;
                }
                back.bplanes.push_back(bplanes[i]);
                break;
            default:
                break;
        }

    }

 	auto res = On;
    if (front.bplanes.size() )
    {
        front.splane = splane;
        front.color = color;
        res = Front;
    }
    if (back.bplanes.size())
    {
        back.splane = splane;
        back.color = color;
        res = Behind;
    }
    if (front.bplanes.size() && back.bplanes.size() )
        return Straddling;

    return res;
}

OutputSymbol   FixedPlanePolygon::LookupEncodingTable(RelationToPlane prevPtPos, RelationToPlane currentPtPos, RelationToPlane nextPtPos) const
{
    if (currentPtPos == Front)
        return B;
    if (currentPtPos == Behind)
    {
        if (nextPtPos == Front)
            return HB;
        return Empty;
    }
    if (nextPtPos ==Front)
    {
        if (prevPtPos == Front )
            return B;
        return  HB;
    }else 
        return Empty;
}


RelationToPlane FixedPlanePolygon::ReverseRelation(RelationToPlane relation) const
{
    switch (relation)
    {
        case Front: 
             return Behind;
        case Behind:
             return Front;
        default:
            return relation;
    }

}

void FixedPlanePolygon::Negate()
{
	splane.Negate();
	auto copy = bplanes;
	bplanes.clear();
	int n = copy.size();
	for (int i = 0; i < n; i++)
	{
		bplanes.push_back(copy.back());
		copy.pop_back();
	}
}

}