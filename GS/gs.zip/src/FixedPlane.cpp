#include "FixedPlane.h"

namespace GS{

bool FixedPlane::IsCoincidence(const FixedPlane& p ) const
{
	if (Distance() != p.Distance() || Normal() != p.Normal()) return false;
	return true; 
}
  
bool FixedPlane::IsParallel(const FixedPlane& p) const
{
     return cross(mNormal,  p.mNormal).isZero();
}

bool FixedPlane::IsSimilarlyOrientation(const FixedPlane& p) const
{
    return ((mNormal.x * p.mNormal.x) + (mNormal.y * p.mNormal.y) 
		+ (mNormal.z* p.mNormal.z)).sign() >= 0;
}

 bool FixedPlane::operator ==(const FixedPlane& p) const
 {
	 if (Distance() != p.Distance()) return false;
     return Normal() == p.Normal();
 }

RelationToPlane FixedPlane::ClassifyPointToPlane(const stdfixed3& p) const 
{
	auto sign = (dot(mNormal, p) + mD).sign();

	if (sign < 0)
        return Behind;
    else if (sign > 0)
        return Front;
    else 
        return On;

}

RelationToPlane FixedPlane::ClassifyPointToPlane(const FixedPlane & p, const FixedPlane & q, const FixedPlane & r) const
{
	stdfixed3x3 ptMat; 
    ptMat[0]= p.mNormal;
    ptMat[1] =q.mNormal;
    ptMat[2] = r.mNormal;
    int detPt =  determinant(ptMat).sign();
    stdfixed4x4 matPlane;
    matPlane[0].xyz(p.mNormal);
    matPlane[0].w(p.mD);
    matPlane[1].xyz(q.mNormal);
    matPlane[1].w(q.mD);
    matPlane[2].xyz(r.mNormal);
    matPlane[2].w(r.mD);
    matPlane[3].xyz(mNormal);
    matPlane[3].w(mD);
    int dist =  detPt*determinant(matPlane).sign();
     if (dist < 0)
        return Behind;
    else if (dist > 0)
        return Front;
    else 
        return On;
}
}