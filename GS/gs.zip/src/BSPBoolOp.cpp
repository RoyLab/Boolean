#include "BSPBoolOp.h"
#include "PlaneMesh.h"
#include "BSPTree.h"
#include "OctTree.h"
#include "FixedPlaneMesh.h"
#include "FixedBSPTree.h"
#include <iostream>

namespace GS{



BSPBoolOp:: ~BSPBoolOp()
{

}


BoolOp* BSPBoolOp::GetInstance()
{
    static BSPBoolOp boolOp;
    return &boolOp;
}



BaseMesh* BSPBoolOp::ComputeBoolean(BaseMesh* mesh1, BaseMesh* mesh2, BOOL_OP op)
{
 
    PlaneMesh* pPlaneMesh1 = mesh1->ToPlaneMesh();
    PlaneMesh* pPlaneMesh2 = mesh2->ToPlaneMesh();
    BaseMesh* pMesh = ComputeBoolean(pPlaneMesh1, pPlaneMesh2, op);
    delete pPlaneMesh1;
    delete pPlaneMesh2;
    return pMesh;
}

BaseMesh* BSPBoolOp::ComputeBoolean(PlaneMesh* mesh1, PlaneMesh* mesh2, BOOL_OP op)
{
    BSPTree::SET_OP BSPOp;
    switch (op)
    {
        case eUnion:
            BSPOp = BSPTree::OP_UNION;
            break;
        case eIntersect:
            BSPOp = BSPTree::OP_INTERSECT;
            break;
        case eDiff:
            BSPOp = BSPTree::OP_DIFFERENCE;
            break;
        default :
            break;
    }
	Box3 bbox(mesh1->AABB());
	bbox.IncludeBox(mesh2->AABB());

    BSPTree* pTree1 =  mesh1->ToBSPTree();
    pTree1->FormSubHyperPlane(bbox);

    BSPTree* pTree2 = mesh2->ToBSPTree();
    if (BSPOp == BSPTree::OP_DIFFERENCE)
    {
        pTree2->Negate();
        BSPOp = BSPTree::OP_INTERSECT;
    }
    pTree2->FormSubHyperPlane(bbox);

    BSPTree* pResultTree = pTree1->Merge(pTree2, BSPOp);
    delete pTree1;
    delete pTree2;

   
   PlaneMesh* pPlaneMesh1 = new PlaneMesh(pResultTree);
    BaseMesh* pMesh = pPlaneMesh1->ToBaseMesh();
    if (pMesh && pMesh->PrimitiveCount() ==0 )
	{
        delete pMesh;
        pMesh = NULL;
    }
    delete pPlaneMesh1;

	//BSPTree *tree = pPlaneMesh1->ToBSPTree();
	//PlaneMesh *pl = new PlaneMesh(tree);
	//BaseMesh *pMesh = pl->ToBaseMesh();
    return pMesh;
}


BaseMesh*  BSPBoolOp::Evalute(std::vector<BaseMesh*>& meshList, std::string& postfix) 
{
    return NULL;
}

///////////////////////////////////////////////////////////////////////////////////

LBSPBoolOp:: ~LBSPBoolOp()
{
}


BoolOp* LBSPBoolOp::GetInstance()
{
    static LBSPBoolOp boolOp;
    return &boolOp;
}

BaseMesh* LBSPBoolOp::ComputeBoolean(BaseMesh* mesh1,  BaseMesh* mesh2, BOOL_OP op)
{

    std::vector<BaseMesh*> meshes(2);
    meshes[0] =mesh1;
    meshes[1]= mesh2;
    OctTree * pOctTree = new OctTree();
    pOctTree->BuildOctTree(meshes);
    std::vector<PlaneMesh*> criticalMeshes;
    pOctTree->GenMeshesFromCriticalCells(criticalMeshes);
    BaseMesh* pResult = BSPBoolOp::ComputeBoolean(criticalMeshes[0], criticalMeshes[1], op);

    delete criticalMeshes[0];
    delete criticalMeshes[1];
    criticalMeshes.clear();

    if (op == eUnion || op == eDiff)
    {
        std::vector<BaseMesh*> NonCriticalMeshes;
        pOctTree->GenMeshesFromNonCriticalCells(NonCriticalMeshes);
        if (pResult == nullptr)
            pResult= new BaseMesh();
        if (NonCriticalMeshes.size())
        {
            int nMeshSize  = op == eDiff ? 1: NonCriticalMeshes.size();
            for (int j = 0; j < nMeshSize; j++)
            {
                BaseMesh* pMesh = NonCriticalMeshes[j];
                for (int i = 0; i < pMesh->PrimitiveCount(); i++) 
                {
                    const TriInfo&  info= pMesh->TriangleInfo(i);
                    pResult->Add(pMesh->Vertex(info.VertexId[0]) , pMesh->Vertex(info.VertexId[1]), pMesh->Vertex(info.VertexId[2]));
                }

            }
            delete NonCriticalMeshes[0];
            delete NonCriticalMeshes[1];
            NonCriticalMeshes.clear();
        }
    }
    delete pOctTree;

    if (pResult && pResult->PrimitiveCount() ==0 )
    {
        delete pResult;
        pResult = NULL;
    }
    return pResult;


}

BaseMesh*  LBSPBoolOp::Evalute(std::vector<BaseMesh*>& meshList, std::string& postfix) 
{
    return NULL;
}


}

