#include "CSGMesh.h"
#include <assert.h>
#include "tbb\tick_count.h"
namespace GS{


CSGMesh::CSGMesh(bool bUseUniqueVertex )
	:BaseMesh(bUseUniqueVertex)
{
}

/*
constructor TCSGMesh.Create(aMesh: TBaseMesh);
begin
  FInterCarveMeshID := TList<Integer>.Create;
  FTriMeshRelation := TObjectList<TRelationRecList>.Create;

  AssignFrom(aMesh);
end;
*/
CSGMesh::CSGMesh(BaseMesh* pMesh)
	:BaseMesh(*pMesh)
{
	CSGMesh* pCSGMesh = dynamic_cast<CSGMesh*>(pMesh);
	if (pCSGMesh)
	{
		mInterCarveMeshID = pCSGMesh->mInterCarveMeshID;
		mTriMeshRelation = pCSGMesh->mTriMeshRelation;
	}

}

CSGMesh::~CSGMesh()
{
	mInterCarveMeshID.clear();
	mTriMeshRelation.clear();
}

bool CSGMesh::InterCarve(CSGMesh& mesh)
{
    if (!AABB().Intersects(mesh.AABB()))
		return false ;
	bool bResult = false ;
	for (int i = 0 ; i < mSurfaceList.size(); i++)
	{
		for (int j = 0 ; j < mesh.mSurfaceList.size(); j++)
		{
			if(!mSurfaceList[i]->AABB().Intersects(mesh.mSurfaceList[j]->AABB()))
				continue;
			for (int m = 0 ; m < mSurfaceList[i]->TriangleCount(); m++)
			{
				int  TriAId = mSurfaceList[i]->GetTriangleId(m);
				for (int k = 0 ; k < mesh.mSurfaceList[j]->TriangleCount(); k++)
				{
					std::vector<Seg3D<double> > intersects;
					int TriBId = mesh.mSurfaceList[j]->GetTriangleId(k);
 					bool bCarved = TrianglesIntersectTest(TriAId, mesh,TriBId, intersects);
					if (bCarved)
					{
						for ( int s = 0 ; s < intersects.size(); s++)
						{
							mSurfaceList[i]->AddConstraint(intersects[s].start, intersects[s].end, mesh.GetID());
							AddCarveMeshID(mesh.GetID());
							mesh.mSurfaceList[j]->AddConstraint(intersects[s].start, intersects[s].end, GetID());
							mesh.AddCarveMeshID(GetID());
							bResult = true;
						}
					}
					intersects.clear();
				}
			}

		}
	}
	return bResult;


}

void CSGMesh::Uncarve(int MeshId)
{

}

CSGMesh* CSGMesh::TriangulateByCarve(bool UseUniqueVertex)
{

  //TODO: �����ò���Ψһ����Լ����ֵ�ÿ���
	CSGMesh* TriMesh = new CSGMesh(UseUniqueVertex) ;
    TriMesh->SetID(GetID());
    TriMesh->SetAABB(AABB());
	ListOfvertices vertices;
	for (int i = 0; i < mSurfaceList.size(); i++)
	{
		if (!mSurfaceList[i]->Triangulated())
		{
			vertices.clear();
			mSurfaceList[i]->Triangulate(vertices);
			for (int k = 0 ; k < vertices.size(); k+=3)
			{   
				TriMesh->Add(vertices[k], vertices[k+1], vertices[k+2], mSurfaceList[i]->N());
			}
		}else {

			for(int j = 0; j< mSurfaceList[i]->TriangleCount(); j++)
			{
				int TriId = mSurfaceList[i]->GetTriangleId(j);
				TriMesh->AddTriangle(this, TriId);
			}

		}
	}
   
    return TriMesh; 
}

inline
PointMeshRelation CSGMesh::PointRelatedWithPlane(const Point3D& TriPos,const Vec3D& TriN,
		                                         const Point3D& p, const Point3D& n)
{
	double DotDist = dot((TriPos - p), n);
	if (IsEqual(fabs(DotDist), 0. , (double)EPSF /*(double)PLANE_THICK_EPS*/))
	{
		if (dot(TriN, n) > 0) 
			return pmrSame;
		else
			return pmrOpposite;
	}else if (DotDist > 0 )    
		return pmrInside;
	return pmrOutside;
}

TriMeshRelation CSGMesh::RelatedWith(int TriId, BaseMesh* mesh )
{
    if (!AABB().Intersects(mesh->AABB()))
		return tmrOutside;

	PointMeshRelation Relation;
	if (mesh->GetManifordType() == mtRegular)//��������
			Relation = mesh->RelationWith(CenterOfGravity(TriId),TriangleInfo(TriId).Normal);
	else //ƽ�棬�ϲ�Ϊinside, �²�Ϊoutside
	{
		const Vec3D& n = mesh->TriangleInfo(0).Normal;
		Vec3D p = mesh->Vertex(mesh->TriangleInfo(0).VertexId[0]).pos;
		Relation = PointRelatedWithPlane(CenterOfGravity(TriId),TriangleInfo(TriId).Normal, p, n);
	}
	switch( Relation)
	{
			case pmrOutside: return tmrOutside;
			case pmrInside:   return tmrInside;
			case pmrSame:     return tmrSame;
			case pmrOpposite: return tmrOpposite;
			default:
			{
				assert(0);
				return tmrUnknown;
			}
	}
 
}


//NOTE: ע��������ж������������������꣬���п������ȶ���������Ƿȱ
void CSGMesh::RelatedWith(BaseMesh* mesh)
{
	if (mTriMeshRelation.size() ==0)
        mTriMeshRelation.resize(PrimitiveCount());
    if (!AABB().Intersects(mesh->AABB()))
		return ;
	const Vec3D& n = mesh->TriangleInfo(0).Normal;
	Vec3D p = mesh->Vertex(mesh->TriangleInfo(0).VertexId[0]).pos;
	for (int i = 0 ; i< PrimitiveCount(); i++)
	{
		PointMeshRelation Relation;
		if (mesh->GetManifordType() == mtRegular)//��������
			Relation = mesh->RelationWith(CenterOfGravity(i),TriangleInfo(i).Normal);
		else //ƽ�棬�ϲ�Ϊinside, �²�Ϊoutside
			Relation = PointRelatedWithPlane(CenterOfGravity(i),TriangleInfo(i).Normal, p, n);
		TriMeshRelation TriRelation;
		switch( Relation)
		{
			case  pmrInside: 
				TriRelation = tmrInside;
				break;
			case pmrSame: 
				TriRelation = tmrSame;
				break;
            case pmrOpposite:
				TriRelation = tmrOpposite;
				break;
			default:
				continue;
		}
		AddRelation(i, mesh->GetID(), TriRelation);
	}	
}




void CSGMesh::AddCarveMeshID(int ID)
{
	if (std::find(mInterCarveMeshID.begin(), mInterCarveMeshID.end(), ID) == mInterCarveMeshID.end())
		mInterCarveMeshID.push_back(ID);
}

void CSGMesh::AddRelation(int TriId, int RelatedMeshID, TriMeshRelation Relation)
{
	ListOfRelationRec& RecList = mTriMeshRelation[TriId];
	for (int i = 0; i < RecList.size(); i++)
	{
		if (RecList[i].MeshID == RelatedMeshID)
		{
			assert(Relation == RecList[i].Relation);
			return ;
		}
	}
    RelationRec Rec;
    Rec.MeshID = RelatedMeshID;
    Rec.Relation = Relation;
	RecList.push_back(Rec);
}

CSGMesh* CSGMesh::ForceTriangulate()
{
	std::vector<bool> Constraint(mSurfaceList.size());
	for (int i = 0; i< mSurfaceList.size(); i++)
	{
		Constraint.push_back(mSurfaceList[i]->HasConstraint());
		mSurfaceList[i]->SetConstraint(true);
		mSurfaceList[i]->SetTriangulateMethod(tmOld);
	}
	CSGMesh* pMesh =TriangulateByCarve(true); 
	for (int i = 0; i< mSurfaceList.size(); i++)
	{
		
		mSurfaceList[i]->SetConstraint(Constraint[i]);
		mSurfaceList[i]->SetTriangulateMethod(tmNew);
	}
	Constraint.clear();
	return pMesh;
}


}
